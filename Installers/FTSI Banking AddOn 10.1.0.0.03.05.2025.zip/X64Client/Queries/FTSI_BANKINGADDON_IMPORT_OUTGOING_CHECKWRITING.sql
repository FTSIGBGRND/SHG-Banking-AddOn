/*
Description:		IMPORT BANKING ADDON - OUTGOING CHECK WRITING
Last Date Modified: 11/30/2020
Modified By:		EMMANUEL PANTE
Version:			1.0.0
*/

/* 
exec [dbo].[FTSI_BANKINGADDON_IMPORT_OUTGOING_CHECKWRITING]  'V1010'
*/

IF OBJECT_ID('[dbo].[FTSI_BANKINGADDON_IMPORT_OUTGOING_CHECKWRITING]','P')IS NOT NULL

DROP PROCEDURE [dbo].[FTSI_BANKINGADDON_IMPORT_OUTGOING_CHECKWRITING]

GO

CREATE PROCEDURE  [dbo].[FTSI_BANKINGADDON_IMPORT_OUTGOING_CHECKWRITING]
	
	@CardCode AS NVARCHAR(30)
	
WITH ENCRYPTION

AS

BEGIN

SELECT	OPCH."DocEntry", 
		OPCH."DocNum", 
		OPCH."DocDate", 
		OPCH."DocDueDate", 
		(OPCH."DocTotal" - OPCH."PaidToDate" - ISNULL(OOCW."U_TotPay",0)) AS "DocTotal", 
		DATEDIFF(DAY, OPCH."DocDueDate", GETDATE()) AS  "OverDue", 
		OPCH."ObjType", 
		'' AS "DocLine", 
		'1' AS "InstId"

FROM OPCH LEFT JOIN (SELECT OCW1."U_BaseEntry", OCW1."U_BaseType", SUM(ISNULL(OCW1."U_TotPay", 0)) AS "U_TotPay"
                    FROM "@FTOOCW" OOCW INNER JOIN "@FTOCW1" OCW1 ON OOCW."DocEntry" = OCW1."DocEntry"
                    WHERE OOCW."U_Status" NOT IN ('X', 'P')
                    GROUP BY OCW1."U_BaseEntry", OCW1."U_BaseType") OOCW ON OOCW."U_BaseEntry" = OPCH."DocEntry" AND OOCW."U_BaseType" = OPCH."ObjType"

WHERE (OPCH."DocTotal" - OPCH."PaidToDate" - ISNULL(OOCW."U_TotPay",0)) * -1 <> 0 AND  
	  OPCH."DocStatus" = 'O' AND OPCH."CardCode" =  @CardCode


UNION ALL

SELECT	ORPC."DocEntry",
		ORPC."DocNum",
		ORPC."DocDate",
		ORPC."DocDueDate",
		(ORPC."DocTotal" - ORPC."PaidToDate" - (ISNULL(OOCW."U_TotPay", 0)*-1)) * -1 AS "DocTotal",
		DATEDIFF(DAY, "DocDueDate", GETDATE()) AS "OverDue", 
		ORPC."ObjType", 
		'' AS "DocLine", 
		'1' AS "InstId"

FROM ORPC LEFT JOIN (SELECT OCW1."U_BaseEntry", OCW1."U_BaseType", SUM(ISNULL(OCW1."U_TotPay", 0)) AS "U_TotPay"
                    FROM "@FTOOCW" OOCW INNER JOIN "@FTOCW1" OCW1 ON OOCW."DocEntry" = OCW1."DocEntry"
                    WHERE OOCW."U_Status" NOT IN ('X', 'P')
                    GROUP BY OCW1."U_BaseEntry", OCW1."U_BaseType") OOCW ON OOCW."U_BaseEntry" = ORPC."DocEntry" AND OOCW."U_BaseType" = ORPC."ObjType"

WHERE (ORPC."DocTotal" - ORPC."PaidToDate" - (ISNULL(OOCW."U_TotPay", 0) *-1)) * -1 <> 0 AND  
	   ORPC.DocStatus = 'O' AND ORPC.CardCode = @CardCode

UNION ALL

SELECT	ODPO."DocEntry", 
		ODPO."DocNum", 
		ODPO."DocDate", 
		ODPO."DocDueDate", 
		(ODPO."DocTotal" - ODPO."PaidToDate" - ISNULL(OOCW."U_TotPay", 0)) AS "DocTotal",
		DATEDIFF(DAY, "DocDueDate", GETDATE()) AS "OverDue", 		
		ODPO."ObjType", 
		'' AS "DocLine", 
		'1' AS "InstId"

FROM ODPO LEFT JOIN (SELECT OCW1."U_BaseEntry", OCW1."U_BaseType", SUM(ISNULL(OCW1."U_TotPay",0)) AS "U_TotPay"
				     FROM "@FTOOCW" OOCW INNER JOIN "@FTOCW1" OCW1 ON OOCW."DocEntry" = OCW1."DocEntry"
				     WHERE OOCW.U_Status NOT IN ('X', 'P')
					 GROUP BY OCW1."U_BaseEntry", OCW1."U_BaseType") OOCW ON OOCW."U_BaseEntry" = ODPO.DocEntry AND OOCW."U_BaseType" = ODPO."ObjType"

WHERE (ODPO.DocTotal - ODPO.PaidToDate - ISNULL(OOCW."U_TotPay",0)) <> 0 AND  
       ODPO.DocStatus = 'O' AND ODPO.CardCode = @CardCode

UNION ALL

SELECT	OJDT."TransId", 
		OJDT."TransId", 
		OJDT."RefDate", 
		OJDT."DueDate", 
		(JDT1."BalDueDeb" - (ISNULL(OOCW."U_TotPay", 0) * -1)) * -1  AS "DocTotal",
		DATEDIFF(DAY,OJDT."DueDate", GETDATE()) AS "OverDue",
		OJDT."TransType" AS "ObjType",
		JDT1."Line_ID" AS "DocLine", 
		'1' AS "InstId"

FROM OJDT INNER JOIN JDT1 ON JDT1."TransId" = OJDT."TransId" 
          LEFT JOIN (SELECT OCW1."U_BaseEntry", OCW1."U_BaseType", SUM(ISNULL(OCW1."U_TotPay", 0)) AS "U_TotPay", OCW1."U_DocLine"
                     FROM "@FTOOCW" OOCW INNER JOIN "@FTOCW1" OCW1 ON OOCW."DocEntry" = OCW1."DocEntry"
                     WHERE OOCW."U_Status" NOT IN ('X', 'P')
                     GROUP BY OCW1."U_BaseEntry", OCW1."U_BaseType", OCW1."U_DocLine") OOCW ON OOCW."U_BaseEntry" = OJDT.TransId AND OOCW."U_BaseType" = OJDT.TransType AND OOCW."U_DocLine" = JDT1.Line_ID

WHERE OJDT."TransType" = '30' AND (JDT1."BalDueDeb" - (ISNULL(OOCW."U_TotPay",0) * -1)) * -1 < 0 AND JDT1.ShortName = @CardCode

UNION ALL

SELECT	OJDT."TransId", 
		OJDT."TransId", 
		OJDT."RefDate", 
		OJDT."DueDate",
		(JDT1."BalDueCred" - ISNULL(OOCW."U_TotPay", 0)) AS "DocTotal",
		DATEDIFF(DAY,OJDT."DueDate", GETDATE()) AS "OverDue",
		OJDT."TransType" AS "ObjType",
		JDT1."Line_ID" AS "DocLine", 
		'1' AS "InstId"

FROM OJDT INNER JOIN JDT1 ON JDT1."TransId" = OJDT."TransId" 
        LEFT JOIN (SELECT OCW1."U_BaseEntry", OCW1."U_BaseType", SUM(ISNULL(OCW1."U_TotPay", 0)) AS "U_TotPay", OCW1."U_DocLine"
                   FROM "@FTOOCW" OOCW INNER JOIN "@FTOCW1" OCW1 ON OOCW."DocEntry" = OCW1."DocEntry"
                   WHERE OOCW."U_Status" NOT IN ('X', 'P')
                   GROUP BY OCW1."U_BaseEntry", OCW1."U_BaseType", OCW1."U_DocLine") OOCW ON OOCW."U_BaseEntry" = OJDT.TransId AND OOCW."U_BaseType" = OJDT.TransType AND OOCW."U_DocLine" = JDT1.Line_ID

WHERE OJDT."TransType" = '30' AND (JDT1."BalDueCred" - ISNULL(OOCW."U_TotPay",0)) > 0 AND JDT1."ShortName" = @CardCode

END