
/*
Description:		EXPORT BANKING ADDON - OUTGOING BANK INTEGRATION LINE DETAILS UB
Last Date Modified: 11/30/2020
Modified By:		EMMANUEL PANTE
Version:			1.0.0
*/

/* 
exec [dbo].[FTSI_BANKINGADDON_EXPORT_OUTGOING_BANKINTEGRATION_LINEDETAILS_UB]  '1', '12313213'
*/

IF OBJECT_ID('[dbo].[FTSI_BANKINGADDON_EXPORT_OUTGOING_BANKINTEGRATION_LINEDETAILS_UB]','P')IS NOT NULL

DROP PROCEDURE [dbo].[FTSI_BANKINGADDON_EXPORT_OUTGOING_BANKINTEGRATION_LINEDETAILS_UB]

GO

CREATE PROCEDURE  [dbo].[FTSI_BANKINGADDON_EXPORT_OUTGOING_BANKINTEGRATION_LINEDETAILS_UB]
	
	@DocEntry AS INT,
	@Account AS NVARCHAR(30)
	
WITH ENCRYPTION

AS

BEGIN

SELECT	OOCW."U_Account",
		OOCW."U_TotalDue",
		'1' AS "Type",
		'CHU' + '|' +
		CAST(OOCW."DocEntry" AS NVARCHAR(50)) + '|' +
		CAST(CAST(ROUND(OOCW."U_TotalDue", 2) AS DECIMAL(19, 2)) AS NVARCHAR(50)) + '|' +
		CAST(ISNULL(OOCW."U_PayName", OOCW."U_CardName") AS NVARCHAR(200)) + '|' +
		CAST(CRD1."ZipCode" AS NVARCHAR(50)) + '|' +
		CAST(REPLACE(OCRD."LicTradNum", '-', '') AS NVARCHAR(15)) + '|' +
		CAST(CRD1."Street" AS NVARCHAR(254)) + '|' +
		CONVERT(VARCHAR, OOCW."U_DueDate", 101) + '|'+
		CAST(BARB."U_Type" AS NVARCHAR(50)) + '|' +
		CAST(OOCW."U_RBranch" AS NVARCHAR(50)) + '|' +
		CAST(CASE WHEN OOCW."U_CrsChk" = 'Y' THEN '1' ELSE '0' END AS NVARCHAR(50)) + '|' +
		CAST(CASE WHEN ISNULL(PCH5."WTAmnt", '0') <> '0' THEN '1' ELSE '0' END AS NVARCHAR(50)) + '|' +
		CAST(CASE WHEN ISNULL(OOCW.U_CheckNo, '0') = '0' THEN '0' ELSE '1' END AS NVARCHAR(50)) + '|' +
		CAST(CASE WHEN ISNULL(OOCW.U_CheckNo, '0') = '0' THEN '0' ELSE OOCW.U_CheckNo END AS NVARCHAR(50)) + '|' +
		'0' + '|' +
		'' + '|' +
		'' + '|' +
		'' AS 'LineDetails'

FROM "@FTOOCW" OOCW INNER JOIN OCRD ON OOCW."U_CardCode" = OCRD."CardCode"
					INNER JOIN CRD1 ON OCRD."BillToDef" = CRD1."Address"
					INNER JOIN "@FTBARB" BARB ON OOCW."U_RBranch" = BARB."Code"
					LEFT JOIN (SELECT OCW1."DocEntry", SUM(PCH5."WTAmnt") AS "WTAmnt"
							   FROM "@FTOCW1" OCW1 INNER JOIN PCH5 ON OCW1."U_BaseEntry" = PCH5.AbsEntry
							   WHERE OCW1."U_BaseType" = '18'
							   GROUP BY OCW1."DocEntry") AS PCH5 ON PCH5."DocEntry" = OOCW."DocEntry"

WHERE OOCW.DocEntry = @DocEntry AND OOCW."U_Account" = @Account

UNION ALL

SELECT	OOCW."U_Account",
		0 AS "TotalDue",
		'1' AS "Type",
		'CWTLN' + '|' +
		
		CAST(CASE WHEN OCW1.U_BaseType = '18' THEN CAST(ISNULL(OPCH.WTCode, '') AS NVARCHAR(30))
				  WHEN OCW1.U_BaseType = '19' THEN CAST(ISNULL(ORPC.WTCode, '') AS NVARCHAR(30))
				  WHEN OCW1.U_BaseType = '204' THEN CAST(ISNULL(ODPO.WTCode, '') AS NVARCHAR(30))
				  WHEN OCW1.U_BaseType = '30' THEN CAST('' AS NVARCHAR(30)) END AS NVARCHAR(30)) + '|' +

		CAST(CASE WHEN OCW1.U_BaseType = '18' AND OFPR.U_Quarter = '1' THEN CAST(CAST(ROUND(ISNULL(OPCH.DocTotal, '0'), 2) AS DECIMAL(19,2)) AS NVARCHAR(30))
				  WHEN OCW1.U_BaseType = '19' AND OFPR.U_Quarter = '1' THEN CAST(CAST(ROUND(ISNULL(ORPC.DocTotal, '0'), 2) AS DECIMAL(19,2)) AS NVARCHAR(30))
				  WHEN OCW1.U_BaseType = '204' AND OFPR.U_Quarter = '1' THEN CAST(CAST(ROUND(ISNULL(ODPO.DocTotal, '0'), 2) AS DECIMAL(19,2)) AS NVARCHAR(30))
				  WHEN OCW1.U_BaseType = '30' THEN CAST('0' AS NVARCHAR(30)) ELSE '0' END  AS NVARCHAR(30)) + '|' +
		
		CAST(CASE WHEN OCW1.U_BaseType = '18' AND OFPR.U_Quarter = '2' THEN CAST(CAST(ROUND(ISNULL(OPCH.DocTotal, '0'), 2) AS DECIMAL(19,2)) AS NVARCHAR(30))
				  WHEN OCW1.U_BaseType = '19' AND OFPR.U_Quarter = '2' THEN CAST(CAST(ROUND(ISNULL(ORPC.DocTotal, '0'), 2) AS DECIMAL(19,2)) AS NVARCHAR(30))
				  WHEN OCW1.U_BaseType = '204' AND OFPR.U_Quarter = '2' THEN CAST(CAST(ROUND(ISNULL(ODPO.DocTotal, '0'), 2) AS DECIMAL(19,2)) AS NVARCHAR(30))
				  WHEN OCW1.U_BaseType = '30' THEN CAST('0' AS NVARCHAR(30)) ELSE '0' END  AS NVARCHAR(30)) + '|' +

		CAST(CASE WHEN OCW1.U_BaseType = '18' AND OFPR.U_Quarter = '3' THEN CAST(CAST(ROUND(ISNULL(OPCH.DocTotal, '0'), 2) AS DECIMAL(19,2)) AS NVARCHAR(30))
				  WHEN OCW1.U_BaseType = '19' AND OFPR.U_Quarter = '3' THEN CAST(CAST(ROUND(ISNULL(ORPC.DocTotal, '0'), 2) AS DECIMAL(19,2)) AS NVARCHAR(30))
				  WHEN OCW1.U_BaseType = '204' AND OFPR.U_Quarter = '3' THEN CAST(CAST(ROUND(ISNULL(ODPO.DocTotal, '0'), 2) AS DECIMAL(19,2)) AS NVARCHAR(30))
				  WHEN OCW1.U_BaseType = '30' THEN CAST('0' AS NVARCHAR(30)) ELSE '0' END  AS NVARCHAR(30)) + '|' +

		CAST(CASE WHEN OCW1.U_BaseType = '18' THEN CAST(CAST(ROUND(ISNULL(OPCH.WTAmnt, '0'), 2) AS DECIMAL(19,2)) AS NVARCHAR(30))
				  WHEN OCW1.U_BaseType = '19' THEN CAST(CAST(ROUND(ISNULL(ORPC.WTAmnt, '0'), 2) AS DECIMAL(19,2)) AS NVARCHAR(30))
				  WHEN OCW1.U_BaseType = '204' THEN CAST(CAST(ROUND(ISNULL(ODPO.WTAmnt, '0'), 2) AS DECIMAL(19,2)) AS NVARCHAR(30))
				  WHEN OCW1.U_BaseType = '30' THEN CAST('0' AS NVARCHAR(30)) END AS NVARCHAR(30)) + '|' +

		CAST(CASE WHEN OCW1.U_BaseType = '18' THEN CAST(CAST(ROUND(ISNULL(OPCH."TaxbleAmnt", '0'), 2) AS DECIMAL(19,2)) AS NVARCHAR(30))
				  WHEN OCW1.U_BaseType = '19' THEN CAST(CAST(ROUND(ISNULL(ORPC."TaxbleAmnt", '0'), 2) AS DECIMAL(19,2)) AS NVARCHAR(30))
				  WHEN OCW1.U_BaseType = '204' THEN CAST(CAST(ROUND(ISNULL(ODPO."TaxbleAmnt", '0'), 2) AS DECIMAL(19,2)) AS NVARCHAR(30))
				  WHEN OCW1.U_BaseType = '30' THEN CAST('0' AS NVARCHAR(30)) END AS NVARCHAR(30)) + '|' +
		
		CONVERT(VARCHAR, OOCW."U_DueDate", 101) + '|'+
		CONVERT(VARCHAR, OOCW."U_DueDate", 101) AS 'LineDetails'

FROM "@FTOOCW" OOCW INNER JOIN  "@FTOCW1" OCW1 ON OOCW."DocEntry" = OCW1."DocEntry"
				    LEFT JOIN OFPR ON OOCW."Period" = OFPR."AbsEntry"
				    
					LEFT JOIN (SELECT OPCH."DocEntry", OPCH."DocDate", (OPCH."DocTotal" - OPCH."VatSum") AS "DocTotal", OWHT."U_WTCode" AS "WTCode", OWHT."WTName", OFPR."U_Quarter", SUM(PCH5."WTAmnt") AS "WTAmnt", SUM(PCH5."TaxbleAmnt") AS "TaxbleAmnt"
							   FROM OPCH INNER JOIN PCH5 ON OPCH."DocEntry" = PCH5."AbsEntry"
								  	     INNER JOIN OWHT ON PCH5."WTCode" = OWHT."WTCode"
									     INNER JOIN OFPR ON OPCH."FinncPriod" = OFPR."AbsEntry"
							   GROUP BY OPCH."DocEntry", OPCH."DocDate", OPCH."DocTotal", OPCH."VatSum", PCH5."WTCode", OWHT."U_WTCode", OFPR."U_Quarter", OWHT."WTName") AS OPCH ON OCW1."U_BaseEntry" = OPCH."DocEntry" AND OCW1."U_BaseType" = '18'

				    LEFT JOIN (SELECT ORPC."DocEntry", ORPC."DocDate", (ORPC."DocTotal" - ORPC."VatSum") AS "DocTotal", OWHT."U_WTCode" AS "WTCode", OWHT."WTName", OFPR."U_Quarter", SUM(RPC5."WTAmnt") AS "WTAmnt", SUM(RPC5."TaxbleAmnt") AS "TaxbleAmnt"
							   FROM ORPC INNER JOIN RPC5 ON ORPC."DocEntry" = RPC5."AbsEntry"
								   	     INNER JOIN OWHT ON RPC5."WTCode" = OWHT."WTCode"
									     INNER JOIN OFPR ON ORPC."FinncPriod" = OFPR."AbsEntry"
							   GROUP BY ORPC."DocEntry", ORPC."DocDate", ORPC."DocTotal", ORPC."VatSum", RPC5."WTCode", OWHT."U_WTCode", OFPR."U_Quarter", OWHT."WTName") AS ORPC ON OCW1."U_BaseEntry" = ORPC."DocEntry" AND OCW1."U_BaseType" = '19'

				    LEFT JOIN (SELECT ODPO."DocEntry", ODPO."DocDate", (ODPO."DocTotal" - ODPO."VatSum") AS "DocTotal", OWHT."U_WTCode" AS "WTCode", OWHT."WTName", OFPR."U_Quarter", SUM(DPO5."WTAmnt") AS "WTAmnt", SUM(DPO5."TaxbleAmnt") AS "TaxbleAmnt"
							   FROM ODPO INNER JOIN DPO5 ON ODPO."DocEntry" = DPO5."AbsEntry"
									     INNER JOIN OWHT ON DPO5."WTCode" = OWHT."WTCode"
									     INNER JOIN OFPR ON ODPO."FinncPriod" = OFPR."AbsEntry"
							   GROUP BY ODPO."DocEntry", ODPO."DocDate", ODPO."DocTotal", ODPO."VatSum", DPO5."WTCode", OWHT."U_WTCode", OFPR."U_Quarter", OWHT."WTName") AS ODPO ON  OCW1."U_BaseEntry" = ODPO."DocEntry" AND OCW1."U_BaseType" = '204'
							
							   
WHERE OOCW.DocEntry = @DocEntry AND OOCW."U_Account" = @Account

UNION ALL

SELECT	OOCW."U_Account",
		0 AS "TotalDue",
		'1' AS "Type",

		'INV' + '|' +

		CAST(CASE WHEN OCW1.U_BaseType = '18' THEN CAST(ISNULL(OPCH.DocNum, '') AS NVARCHAR(30))
			      WHEN OCW1.U_BaseType = '19' THEN CAST(ISNULL(ORPC.DocNum, '') AS NVARCHAR(30))
			      WHEN OCW1.U_BaseType = '204' THEN CAST(ISNULL(ODPO.DocNum, '') AS NVARCHAR(30))
			      WHEN OCW1.U_BaseType = '30' THEN CAST(ISNULL(OJDT.TransId, '') AS NVARCHAR(30)) END AS NVARCHAR(30)) + '|' +

		CAST(CASE WHEN OCW1.U_BaseType = '18' THEN CAST(ISNULL(CONVERT(VARCHAR, OPCH."DocDate", 101), '') AS NVARCHAR(30))
			      WHEN OCW1.U_BaseType = '19' THEN CAST(ISNULL(CONVERT(VARCHAR, ORPC."DocDate", 101), '') AS NVARCHAR(30))
			      WHEN OCW1.U_BaseType = '204' THEN CAST(ISNULL(CONVERT(VARCHAR, ODPO."DocDate", 101), '') AS NVARCHAR(30))
			      WHEN OCW1.U_BaseType = '30' THEN CAST(ISNULL(CONVERT(VARCHAR, OJDT."RefDate", 101), '') AS NVARCHAR(30)) END AS NVARCHAR(30)) + '|' +

		CAST(CASE WHEN OCW1.U_BaseType = '18' THEN CAST(ISNULL(OPCH."DocTotalWT", '0') AS NVARCHAR(30))
			      WHEN OCW1.U_BaseType = '19' THEN CAST(ISNULL(ORPC."DocTotalWT", '0') AS NVARCHAR(30))
			      WHEN OCW1.U_BaseType = '204' THEN CAST(ISNULL(ODPO."DocTotalWT", '0') AS NVARCHAR(30))
			      WHEN OCW1.U_BaseType = '30' THEN CAST(ISNULL(OCW1.U_BalDue, '0') AS NVARCHAR(30)) END AS NVARCHAR(30)) + '|' +

		CAST(CASE WHEN OCW1.U_BaseType = '18' THEN CAST(ISNULL(OPCH."DocTotal", '0') AS NVARCHAR(30))
			      WHEN OCW1.U_BaseType = '19' THEN CAST(ISNULL(ORPC."DocTotal", '0') AS NVARCHAR(30))
			      WHEN OCW1.U_BaseType = '204' THEN CAST(ISNULL(ODPO."DocTotal", '0') AS NVARCHAR(30))
			      WHEN OCW1.U_BaseType = '30' THEN CAST(ISNULL(OCW1.U_BalDue, '0') AS NVARCHAR(30)) END AS NVARCHAR(30)) + '|' +

		CAST(SUBSTRING(ISNULL(OOCW."U_Comments", ''), 1, 20) AS NVARCHAR(20))  + '|' +
		CAST(SUBSTRING(ISNULL(OOCW."U_Comments", ''), 21, 20) AS NVARCHAR(20)) + '|' +
		CAST(SUBSTRING(ISNULL(OOCW."U_Comments", ''), 41, 20) AS NVARCHAR(20)) + '|' +
		CAST(SUBSTRING(ISNULL(OOCW."U_Comments", ''), 61, 20) AS NVARCHAR(20)) + '|' +				
		CAST(SUBSTRING(ISNULL(OOCW."U_Comments", ''), 81, 20) AS NVARCHAR(20))  AS 'LineDetails'

FROM "@FTOOCW" OOCW INNER JOIN  "@FTOCW1" OCW1 ON OOCW."DocEntry" = OCW1."DocEntry"
				    LEFT JOIN OFPR ON OOCW."Period" = OFPR."AbsEntry"
				    
					LEFT JOIN (SELECT OPCH."DocEntry", OPCH.DocNum, OPCH."DocDate", (OPCH."DocTotal" - OPCH."VatSum") AS "DocTotal", (OPCH."DocTotal" + OPCH."WTSum") AS "DocTotalWT"
							   FROM OPCH) AS OPCH ON OCW1."U_BaseEntry" = OPCH."DocEntry" AND OCW1."U_BaseType" = '18'

				   LEFT JOIN (SELECT ORPC."DocEntry", ORPC.DocNum, ORPC."DocDate", (ORPC."DocTotal" - ORPC."VatSum") AS "DocTotal", (ORPC."DocTotal" + ORPC."WTSum") AS "DocTotalWT"
							  FROM ORPC) AS ORPC ON OCW1."U_BaseEntry" = ORPC."DocEntry" AND OCW1."U_BaseType" = '19'

				   LEFT JOIN (SELECT ODPO."DocEntry", ODPO.DocNum, ODPO."DocDate", (ODPO."DocTotal" - ODPO."VatSum") AS "DocTotal", (ODPO."DocTotal" + ODPO."WTSum") AS "DocTotalWT"
							  FROM ODPO) AS ODPO ON  OCW1."U_BaseEntry" = ODPO."DocEntry" AND OCW1."U_BaseType" = '204'

				  LEFT JOIN (SELECT OJDT."TransId", OJDT."RefDate"
							 FROM OJDT) AS OJDT ON  OCW1."U_BaseEntry" = OJDT."TransId" AND OCW1."U_BaseType" = '30'
							
							   
WHERE OOCW.DocEntry = @DocEntry AND OOCW."U_Account" = @Account

END