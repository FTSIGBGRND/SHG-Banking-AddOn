/*
Description:		IMPORT BANKING ADDON - OUTGOING EMAIL NOTIFICATION
Last Date Modified: 11/30/2020
Modified By:		EMMANUEL PANTE
Version:			1.0.0
*/

/* 
exec [dbo].[FTSI_BANKINGADDON_IMPORT_OUTGOING_EMAILNOTIF]  '12/09/2022'
*/

IF OBJECT_ID('[dbo].[FTSI_BANKINGADDON_IMPORT_OUTGOING_EMAILNOTIF]','P')IS NOT NULL

DROP PROCEDURE [dbo].[FTSI_BANKINGADDON_IMPORT_OUTGOING_EMAILNOTIF]

GO

CREATE PROCEDURE  [dbo].[FTSI_BANKINGADDON_IMPORT_OUTGOING_EMAILNOTIF]
	
	@DocDate AS DATETIME
	
WITH ENCRYPTION

AS

BEGIN

SELECT	'N' AS "Selected",
		OOCW."DocEntry",
		OOCW."DocNum",
		OOCW."U_DocDate",
		OOCW."U_DueDate",
		--OOCW."U_CardCode",
		OOCW."U_CardName",
		--OOCW."U_PayName",
		--OOCW."U_Bank",
		ODSC."BankName" AS "U_Bank",
		OOCW."U_Branch",
		OOCW."U_Account",
		OOCW."U_TotalDue"
		
FROM "@FTOOCW" OOCW INNER JOIN ODSC ON OOCW."U_Bank" = ODSC."BankCode"

WHERE ISNULL (OOCW."U_EmailNotif", 'N') = 'N' AND OOCW.U_Status = 'P' AND OOCW."U_DocDate" = @DocDate 

END


